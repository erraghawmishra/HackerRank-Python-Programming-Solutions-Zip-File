import numpy
arr = numpy.array([int(x) for x in input().strip().split()])
arr.shape = (3, 3)
print(arr)