if __name__ == '__main__':
    n = int(input())
    
    num = 1
    while num <= n:
        print(num, end='')
        num += 1
