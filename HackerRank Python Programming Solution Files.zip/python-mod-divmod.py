output = divmod(int(input().strip()), int(input().strip()))
print(output[0])
print(output[1])
print(output)