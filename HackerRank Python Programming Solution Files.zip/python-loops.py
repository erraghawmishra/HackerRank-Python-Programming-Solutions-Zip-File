if __name__ == '__main__':
    n = int(input())

    num = 0
    while num < n:
        print(pow(num, 2))
        num += 1