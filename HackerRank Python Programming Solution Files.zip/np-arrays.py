def arrays(arr):
    return numpy.array(arr[::-1], float)

