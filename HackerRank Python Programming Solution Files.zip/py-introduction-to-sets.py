def average(array):
    uniq = set(array)
    
    return sum(uniq)/len(uniq)